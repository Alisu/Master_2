package pd;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person(true);
		p.doStuff();
	}

}
