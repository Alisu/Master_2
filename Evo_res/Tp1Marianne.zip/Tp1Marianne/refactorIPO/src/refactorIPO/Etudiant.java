package refactorIPO;

public class Etudiant extends Personne {
	
	int ine;

	public Etudiant(String nom, int numeroRue, String nomRue, String ville, int codePostal, String pays, int ine) {
		super(nom, numeroRue, nomRue, ville, codePostal, pays);
		this.ine=ine;// TODO Auto-generated constructor stub
	}

}
