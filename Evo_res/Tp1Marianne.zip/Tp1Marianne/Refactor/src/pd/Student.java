package pd;

public class Student extends Person{

	public Student(){
		super();
	}

	public void Etudier() {
		skill++;
	}
}