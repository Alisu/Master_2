package item;

public abstract class FilesystemItem {
	
	abstract public void someOtherMethod();

}
