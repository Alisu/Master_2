=================================================================
item package README
=================================================================

Les classes composants le package item effectuent des actions similaires de manière dissemblable. Elles descendent en outre d'une classe abstraite qui ne factorise rien.

Elles bénéficieront de la standardisation et de la normalisation que leur apportera une Interface normalisée qu'elles se partageront.
