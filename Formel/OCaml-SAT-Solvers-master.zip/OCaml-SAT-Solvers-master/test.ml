open Generator

let _ =
  gen_solve_print 4 3 3
